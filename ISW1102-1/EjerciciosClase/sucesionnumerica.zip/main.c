/******************************************************************************

Datos de entrada
Declarar variables i(números),c (contador), s(suma), u(último término)

Proceso
Establecer el primer y último término (sabiendo que la suceción suma 2 y 5 repetitivamente)
Mostrar al usuario la Serie
mientras (i<=2495) entonces
    calcular s=s+1
    calcular i=i+5
    calcular c=c+1
    imprimir el siguiente término i
    calcular s=s+1
    calcular i=i+2
    calcular c=c+1
    imprimir el siguiente término i
fin mientras
imprimir la suma

Datos de salida
Términos de la sucesión numérica
Suma de la sucesión numérica

*******************************************************************************/
#include <stdio.h>/*Incluir biblioteca*/
#include <math.h>/*Incluir biblioteca matemática*/

void main()/*Inicio función principal*/
{/*Inicio*/
    int i=2,c=1,s=0,u=2500;/*declaro variables de tipo entero*/ 
    printf("\t\tSuceción matemática\n");/*Título del programa*/
    printf("");
    printf("---------------------------------------------\n");
    printf("");
    printf("Serie: 2, 7, 10, 15, 18, 23, . . ., 2500 \n");/*Mostrar al usuario la serie*/
    printf("Primer término: %d\n",i);/*Mostrar el primer término*/
    printf("Último término: %d\n",u);/*Mostrar el último término*/
    while(i<2495)/*Inicio función repetitiva*/
        {
            s=s+i;/*Calcular el siguiente término*/
            i=i+5;/*Calcular el siguiente término*/
            c=c+1;/*Calcular el contador*/
            printf("Término N°%i: %i\n", c,i);/*Imprimir el término sumado 5*/
            s=s+i;/*Calcular el siguiente término*/
            i=i+3;/*Calcular el siguiente término*/
            c=c+1;/*Calcular el contador*/
            printf("Término N°%i: %i\n", c,i);/*Imprimir el término sumado 2*/
        }/*Fin de la función while cuando ya no se encuentre entre esa condición*/
    printf("La suma de los términos es: %i \n", s);/*Mostrar al usuario la suma de los términos*/

}/*fin*/

