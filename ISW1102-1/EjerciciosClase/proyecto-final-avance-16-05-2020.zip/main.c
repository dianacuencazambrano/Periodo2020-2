/******************************************************************************

Erick Paredes,Martín Córdova y Diana Cuenca

*******************************************************************************/
#include <stdio.h>
void ingreso(int);
void eliminacion(int);
void modificacion(int);
int main()
{   int op=0,veces1=0,veces2=0,veces3=0,n=0;
    char med1[10],med2[10],med3[10];
    do{
        printf("\t\tProyecto Final\n");
        printf("1. Ingreso Datos\n 2. Eliminacion Datos\n 3. Modificacion Datos\n 4.Salir\n");
        do{
            printf("Ingrese su opcion: ");
            scanf("%i",&op);
            if(op>4||op<0)
            {
                printf("Opcion invalida intentelo de nuevo\n");
            }
        }while(op>4||op<0);
        switch(op)
        {
            case 1:
                printf("\t\tCreacion de perfil de medicamento\n");//Aqui se llama a la funcion de creacion de cuenta
                do{
                    printf("Cuantos medicamentos desea aumentar, max 3: ");
                    scanf("%i",&n);
                    if(n>10||n<1)
                    {
                        printf("Opcion invalida intente de nuevo\n");
                    }
                }while(n>10||n<1);    
                ingreso (n);
            break;
            case 2:
                printf("Eliminacin de perfil de medicamento");//Funcion de la eliminacion de la cuenta
            break;
            case 3:
                printf("Modificacion de perfil de medicamento");//LLamada a la funcion de modificacion
            break;
            default:
                printf("Saliendo");//Mensaje de salida
            break;
        }
    }while(op!=4);
}
void ingreso(int num)
{
    int c=0,h=0,veces1=0,veces2=0,veces3=0;
    char aux[10],med1[10],med2[10],med3[10];
    float med1hora1=0,med1hora2=0,med1hora3=0,med2hora1=0,med2hora2=0,med2hora3=0,med3hora1=0,med3hora2=0,med3hora3=0;
    for(c=1;c<=num;c++)
    {
        if(c==1)
        {
            printf("Ingrese el nombre del medicamento 1: ");
            scanf("%s",med1);
            printf("\nIngrese cuantas veces al dia debe tomar, max3: ");
            scanf("%i",&veces1);
            for(h=1;h<=veces1;h++)
            {
                printf("Ingrese la hora a tomar el medicamento 1: ");
                if(h==1)
                {
                    scanf("%f",&med1hora1);
                }
                else
                {
                    if(h==2)
                    {
                        scanf("%f",&med1hora2);
                    }
                    else
                    {
                        scanf("%f",&med1hora3);
                    }
                }
            }
            
        }
        else
        {
            if(c==2)
            {
                printf("Ingrese el nombre del medicamento: ");
                scanf("%s",med2);
                printf("Ingrese cuantas veces al dia debe tomar: ");
                scanf("%i",&veces2);
                for(h=1;h<=veces2;h++)
                {
                    printf("Ingrese la hora a tomar el medicamento 2: ");
                    if(h==1)
                    {
                        scanf("%f",&med2hora1);
                    }
                    else
                    {
                        if(h==2)
                        {
                            scanf("%f",&med2hora2);
                        }
                        else
                        {
                            scanf("%f",&med2hora3);
                        }
                    }
                }
            }
            else
            {
                if(c==3)
                {
                    printf("Ingrese el nombre del medicamento: ");
                    scanf("%s",med3);
                    printf("Ingrese cuantas veces al dia debe tomar: ");
                    scanf("%i",&veces3);
                    for(h=1;h<=veces3;h++)
                    {
                        printf("Ingrese la hora a tomar el medicamento 3: ");
                        if(h==1)
                        {
                            scanf("%f",&med3hora1);
                        }
                        else
                        {
                            if(h==2)
                            {
                                scanf("%f",&med3hora2);
                            }
                            else
                            {
                                scanf("%f",&med3hora3);
                            }
                        }
                    }
                }
            }
        }
    }
}






