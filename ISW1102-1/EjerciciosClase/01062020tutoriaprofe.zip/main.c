/******************************************************************************

Crear un programa que permita ingresar n notas de un estudiante, imprima las calificaciones,
determine su promedio e indique si aprueba o reprueba.

Ingrese el nombre:Luis
Ingrese la cantidad de notas:-3
Ingrese la cantidad de notas: 3
Ingrese la calificacion:-3
Ingrese la calificacion: 5
Ingrese la calificacion: 7
Ingrese la calificacion: 10

Calificaciones de Luis
Nota 1: 5
Nota 2: 7
Nota 3: 10
El promedio es 7.3


*******************************************************************************/
#include <stdio.h>
#define tam 30
void ingresoNotas(int,float[],char[]);
float promedioEstudiantes(int,float[],char[]);


void main()
{
    int op,cantNum;
    float nota[tam];
    char nombre[tam];
    while(op!=3)
    {
        printf("1.Ingreso Calificaciones\n2.Notas del Estudiante\n3.Salir\n");
        printf("Escoja la opcion:");
        scanf("%d",&op);
        switch(op)
        {
            case 1:
                do
                {
                    printf("Ingrese la cantidad de notas:");
                    scanf("%d",&cantNum);
                }while(cantNum<0);
            ingresoNotas(cantNum,nota,nombre);
            
            break;
            case 2:
                printf("El promedio es %.1f\n",promedioEstudiantes(cantNum,nota,nombre));
            break;
            default:
                printf("Intente nuevamente. Opcion invalida\n");
            break;
            
        }
    }
}

void ingresoNotas(int cant,float notas[cant],char nombre[])
{
    int i=0;
    getchar();
    printf("Ingrese el nombre:");
    gets(nombre);
    while(i<cant)
    {
        do
        {
            printf("Ingrese la calificacion:");
            scanf("%f",&notas[i]);
        }while(notas[i]<0);
    i++;   
    }
    
}

float promedioEstudiantes(int c, float n[c],char nombre[])
{
    int i=0;
    float  promedio=0,suma=0;
    printf("Calificaciones de %s\n",nombre);
    while(i<c)
    {
        printf("Nota%d=%.1f\n",i+1,n[i]);
        suma=suma+n[i];
    i++;   
    }
    promedio=suma/c;
    if(promedio>=6)
    {
        printf("%s aprueba\n",nombre);
    }
    else
    {
         printf("%s reprueba\n",nombre);
    }
    return promedio;
}