/******************************************************************************

Crea un programa que permita realizar la tabla de multiplicar de cualquier número
e imprima en la pantalla

5x1=5
5x2=10
5x3=15

*******************************************************************************/
#include <stdio.h>

void main()
{
    int lim, tabla, mult=0, cont=1;
    printf("Ingrese la tabla a múltiplicar: ");
    scanf("%d",&tabla);
    printf("Ingrese el límite a múltiplicar: ");
    scanf("%d",&lim);
    while(cont<=lim)
    {
        mult=tabla*cont;
        printf("%dx%d=%d\n",tabla, cont, mult);
        cont++;
    }


}
