/******************************************************************************

Programa para obtener la solución o soluciones de una función cuadrática.
Datos de entrada: a(valor que acompaña a x^2), b (valor que compaña a la x) y (constante)
Proceso
Escribir "Ingrese el coeficiente de x^2"
leer a
Escribir "Ingrese el coeficiente de x"
leer b
Escribir "Ingrese el valor de la constante"
leer c
calcular x1=(-b)+raiz(b^2)
Datos de salida: valor de X1 y X2


*******************************************************************************/
#include <stdio.h>/*Incluir la biblioteca*/
#include <math.h> /*Incluir la biblioteca*/

void main()/*inicio funcion principal*/
{/*Inicio*/
    float a,b,c,x1,x2, discriminante;/*declarar variables*/
    printf("Ingrese el coeficiente de x^2: ");/*Pedir al usuario que ingrese el primer dato*/
    scanf("%f",&a);/*leer el dato y alamcenar*/
    printf("Ingrese el coeficiente de x: ");/*Pedir al usuario que ingrese el segundo dato*/
    scanf("%f",&b);/*leer el dato y alamcenar*/
    printf("Ingrese el valor de la constante: ");/*Pedir al usuario que ingrese el tercer dato*/
    scanf("%f",&c);/*leer el dato y alamcenar*/
    discriminante=pow(b,2)-4*a*c;/*Establesco la fórmula del discriminante*/
    x1=((-(b)-((sqrt(pow(b,2))-4*a*c)))/2*a);;/*Establezco la fórmula de x1*/
    x2=((-(b)+((sqrt(pow(b,2))-4*a*c)))/2*a);/*Establezco la fórmula de x2*/
    printf("X1=%.1f  \n",x1);/*Mostrar en la pantalla la variable x1*/
    printf("X2=%.1f  \n",x2);/*Mostrar en la pantalla la variable x2*/
}
