/******************************************************************************

Crear un programa que permita generar la serie de los n primeros números pares.

inicialización, condición e incremento
Datos de entrada
Entero cont=1, par=0, n;

Proceso
Mientras (cont<=n)
    par=par+2
    Imprimir par
    cont=cont+1

Salida
Par y contador
*******************************************************************************/
#include <stdio.h>

void main()
{
    int cont=1,par=0, n;
    printf("\t\tNumeros pares\n");
    printf("Ingrese la cantidad de numeros: ");
    scanf("%d",&n);
    while(cont<=n)
    {
        par=par+2;
        printf("%d\n", par);
        cont=cont+1;
        
    }
    


}
