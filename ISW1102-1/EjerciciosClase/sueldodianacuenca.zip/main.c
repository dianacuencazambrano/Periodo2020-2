/******************************************************************************

Datos de entrada
Horas trabajdas, género, edad, edad1, años en la empresa, puntaje del examen, sueldo

Proceso
Ingrese si petenece al grupo 1 o 2
leer grupo
si grupo==1 entonces
    pedir años, genero, edad, sueldo
    leer años, genero, edad, sueldo
    si (años>30) entonces
        si(genero==M o años>25)
         mostrar "Aumento de 800 dólares"
         calcular aumento =sueldo+800
         mostrar aumento
    sino
        si(horas>40)
            mostrar "Aumento de 50 dólares"
            calcular aumento =sueldo+50
            mostrar aumento
        sino
         mostrar "Aumento de 100 dólares"
            calcular aumento =sueldo+100
            mostrar aumento
sino
    pedir edad1, puntaje
    leer edad1, puntaje
    si (edad1>18 y puntaje>85)
        mostrar ("Será contradado")
    sino 
        mostrar ("No será contradado")
    

Datos de salida
Si ingreso o no a la empresa.
Aumento del sueldo

*******************************************************************************/
#include <stdio.h>/*Incluimos biblioteca*/

void main()/*Inicio función principal*/
{/*Inicio*/
    int grupo, edad, horas, years, puntos, genero, edad1;/*declaro variables de tipo entero*/
    float sueldo=0, aumento=0; /*declaro variables de tipo flotante*/
    printf("Presione: \n 1. Grupo 1: aumento de sueldo\n 2. Grupo 2: admisión\n");/*Pedir al usuario que ingrese a que grupo pertenece*/
    scanf("%i",&grupo);/*Leer dato y almacenar*/
    if(grupo==1)/*condición, si pertenece al grupo 1 se hace lo siguiente*/
    {
        printf("Ingrese su edad:");/*Pedir al usuario que ingrese su edad*/
        scanf("%d",&edad);/*Leer dato y almacenar*/
        printf("Ingrese su genero (3 para mujer y 4 para hombre):");/*Pedir al usuario que ingrese su genero*/
        scanf("%d",&genero);/*Leer dato y almacenar*/
        printf("¿Cuanto años lleva en la empresa?:");/*Pedir al usuario que ingrese sus años en la empresa*/
        scanf("%d",&years);/*Leer dato y almacenar*/
        printf("Ingrese su sueldo:");/*Pedir al usuario que ingrese su sueldo*/
        scanf("%f",&sueldo);/*Leer dato y almacenar*/
        
        if(years>=30 )/*condición, si lleva más de 30 años en la empresa*/
        {
            if (genero==3 || edad>25) /*condición, si es mujer o tiene más de 25 años*/
                {
                aumento=sueldo+800;/*calcular su aumento en función a la condicion*/
                printf("Su aumento es de $800, es decir, su sueldo es de %f \n", aumento);/*Mostrar al usuario su aumento en función de sus años en la empresa, su género y su edad*/
                }
        }
        else
            {
            if(horas>40)/*condición, si trabajó más de 40 horas*/
                {
                aumento=sueldo+50;/*calcular su aumento en función a la condicion*/
                printf("Su aumento es de $50, es decir, su sueldo es de %f \n", aumento);/*Mostrar al usuario su aumento en función de las horas trabajadas*/
                }
           else
                {
                aumento=sueldo+100;/*calcular su aumento en función a no estar dentro de ninguna condición*/
                printf("Su aumento es de $100, es decir, su sueldo es de %.2f \n", aumento);/*Mostrar al usuario su aumento en función de no estar en ningun condición*/
                    
                }
            }
    }
    else
    {
        
        printf("Ingrese su edad:");/*Pedir al usuario que ingrese su edad*/
        scanf("%i",&edad1);/*Leer dato y almacenar*/
        printf("Ingrese el puntaje que obtuvo en la prueba:");/*Pedir al usuario que el puntaje que obtuvo en la prueba*/
        scanf("%i",&puntos);/*Leer dato y almacenar*/
        
        if(edad1>18 && puntos>85)/*condición, si tiene mas de 18 años y obtuvo mas de 85 puntos en la prueba*/
            {
                printf("Será contratado, Felicidades.");/*Mostrar al usuario que será contratado*/
            }
             
        else
           {
               printf("No será contratado.");/*Mostrar al usuario que no será contratado*/
               
           }
    }       


}/*fin*/
