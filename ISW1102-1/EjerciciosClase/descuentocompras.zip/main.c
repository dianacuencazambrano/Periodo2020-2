/******************************************************************************

Datos de entrada
Valor de la compra (c)

Proceso
Ingrese el monto de su compra
leer c
si (c>500) entonces
    calcular d=c*20/100
    imprimir d
sino
    si (c>1500 && c<=5000) entonces
        calcular d=c*15/100;
        imprimir d 
    sino
        si (c>=800 && c<=1500) entonces
            calcular d=c*10/100;
            imprimir d 
        sino
            imprimir "no tiene descuento"
            
Datos de salida
Monto con el descuento aplicado (d)
Si tiene o no descuento
        
*******************************************************************************/
#include <stdio.h>/*Incluir biblioteca*/
#include <math.h>/*Incluir biblioteca matemática*/

void main()/*Inicio función principal*/
{/*Inicio*/
    float c=0, d=0;/*declaro variables de tipo flotante*/
    printf("             Descuento en su compra\n");/*Título del programa*/
    printf("");
    printf("---------------------------------------------\n");
    printf("");
    printf("Ingrese el monto de su compra: ");/*Pedir al usuario que el monto de la compra*/
    scanf("%f",&c);/*Leer dato y almacenar*/
    if(c>5000)/*condición, si el valor ingresado es mayor a 5000*/
        {
            d=c*20/100; /*calcular descuento en función de la condicion*/
            printf("Su descuento es del 20%\nValor total a pagar: %.2f\n", d);/*Mostrar al usuario su descuento en función de la condición*/
        }
    else
        {
            if(c>1500 && c<=5000)/*condición, si el valor ingresado es mayor a 1500 y menor o igual a 5000*/
                {
                    d=c*15/100;/*calcular descuento en función de la condicion*/
                    printf("Su descuento es del 15%\nValor total a pagar: %.2f\n", d);/*Mostrar al usuario su descuento en función de la condición*/
                }
            else
                {
                    if(c>=800 && c<=1500)/*condición, si el valor ingresado es mayor o igual a 800 y menor o igual a 1500*/
                        {
                            d=c*10/100;/*calcular descuento en función de la condicion*/
                            printf("Su descuento es del 10%\nValor total a pagar: %.2f\n", d);/*Mostrar al usuario su descuento en función de la condición*/
                        }
                    else
                        {
                            printf("No tiene descuento.\nValor total a pagar: %.2f\n", c);/*Mostrar al usuario que no tiene descuento*/
                        }
                }
        }
}/*fin*/
