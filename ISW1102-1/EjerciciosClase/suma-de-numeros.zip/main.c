/******************************************************************************

Crear un programa que permita ingresar or teclado n numeros positivos,
y realice la suma de dichos números.

Datos de entrada
entero cont=1, contnum
real sum=0, n
Proceso
Escribir "Ingrese la cantidad de números"
leer contnum
mientras (cont<=contnum)
    inicio
        escribir "Ingrese el número"
        leer n
        mientras (n<0)
            inicio
                Escribir "Ingrese el numero"
                leer n
            fin
        sum=sum+n
        cont=cont+1
    fin
Imprimir  sum

Datos de salida
sum
*******************************************************************************/
#include <stdio.h>

void main()
{
    int cont=1,contnum;
    float sum=0, n;
    printf("Ingrese la cantidad de números: ");
    scanf("%d",&contnum);
    while (cont<=contnum)
    {
        printf("Ingrese el numero: ");
        scanf("%f",&n);
        while(n<0)
        {
            printf("Ingrese un numero positivo: ");
            scanf("%f",&n);
        }
    sum=sum+n;
    cont++;
    }
printf("la suma es: %f", sum);
}
