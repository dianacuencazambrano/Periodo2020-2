/******************************************************************************

Crear un programa que permita realizar la suma de 2 números, usando funciones
1.Definición de librerias
2.Definición (declaración) de prototipo de funciones
3.Llamada a la función en función principla main()
4.Implementación de la función
float sumaNumeros(float num1, float num2);
float sumaNumeros(float, float);

4 - factorial= (1*2*3*4)

5*1=5
5*2=10
5*3=15

*******************************************************************************/
#include <stdio.h>

int sumaNumeros(int, int);/*Dos argumentos, no interesa el nombre de la variable*/
int factorial(int);/*Prototipos*/
void tablaMult (int,int);

void main()
{
    int numero1, numero2;
    printf("Ingrese el numero 1 y el numero 2:\n");
    scanf("%d %d", &numero1,&numero2);
    printf("\nLa suma es: %d", sumaNumeros(numero1,numero2));/*Invoco la función*/
    printf("\nEl factorial de %d es %d.",numero1,factorial(numero1));
    printf("\nEl factorial de %d es %d.",numero2,factorial(numero2));
    tablaMult (numero1, numero2);/*Invoco s ls función porque dentro de esta ya existe le printf*/
    tablaMult (numero1,numero2);
}
int sumaNumeros(int num1, int num2)/*No tiene (;) si es que ya se plantea la funcion*/
{
    int resul=0;
    resul=num1+num2;
    return resul;
}
int factorial (int num)
{
    int fact=1,cont=1;
    while(cont<=num)
    {
        fact=fact*cont;
        cont++;
    }
    return fact;
}
void tablaMult (int tabla, int lim )
{
    int mult=1, cont=1;
    for(cont=1;cont<=lim;cont++)
    {
        mult=tabla*cont;
        printf("\n%d*%d=%d",tabla,cont,mult);
    }
    
}