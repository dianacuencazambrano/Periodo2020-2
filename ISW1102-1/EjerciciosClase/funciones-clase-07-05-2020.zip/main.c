/******************************************************************************

cuantos numeros va a generar para la serie de n numeros pares
y realice la suma de dichos Números

ingrese la cantidad de números a generar: 3
2
4
6

la suma de los numeros es 14



*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int factorial(int);
void tablaMult(int,int);
int sumaNum(int);
void serie(int);

void main()
{
    int num,nume,n,limite,lim,op;
    while(op!=3)
    {
    printf("1.Factorial\n2.Tabla de Multiplicar\n3.Suma de Números\n4.Serie de números pares\n5.Salir\n");
    printf("Escoja una opcion:");
    scanf("%d",&op);
    
        switch(op)
        {
            case 1:
                printf("Ingrese el numero:");
                scanf("%d",&num);
                while(num<0 )
                {
                    printf("Ingrese un numero positivo:");
                    scanf("%d",&num);
    
                }
                printf("El factorial de %d es %d\n",num,factorial(num));
            break;
            case 2:
                printf("Ingrese la tabla a multiplicar:");
                scanf("%d",&num);
                printf("Ingrese el limite:");
                scanf("%d",&limite);
                tablaMult(num,limite);
            break;
            case 3:
            {
                printf("Ingrese la cantidad de numeros:");
                scanf("%d",&num);
                while(num<0)
                {
                    printf("Ingrese un numero positivo:");
                    scanf("%d",&num);
                }
                printf("La suma es: %d", sumaNum(num));
            }
            break;
            case 4:
            {
                printf("Ingrese la cantidad de numeros para generar la serie:");
                scanf("%d",&n);
                if(n<=0)
                {
                    printf("Número invalido. Ingrese Nuevamente: ");
                    scanf("%d",&n);
                }
                serie(n);
            }
            
            case 5:
                exit(0);
            break;
        }
    }
    
    
}

int factorial(int numero)
{
    int fact=1,cont=1;
    while(cont<=numero)
    {
        fact=fact*cont;
        cont++;
    }
    return fact;
}

void tablaMult(int numero,int lim)
{
    int mult=1,cont;
    for(cont=1;cont<=lim;cont++)
    {
        mult=numero*cont;
        printf("%dX%d=%d\n",numero,cont,mult);
    }
    
}
int sumaNum (int lim)
{
    int cont=1,num, sum=0;
    while(cont<=lim)
    {
        printf("Ingrese el numero %d:", cont);
        scanf("%d",&num);
        while(num<=0)
        {
            printf("Ingrese nuevamente: ");
            scanf("%d",&num);
        }
        sum=sum+num;
        cont++;
    }
    return sum;
    
}
void serie(int nume)
{
    int cont=1,sum=0,par=0;
    while (cont<=nume)
    {
        par=par+2;
        printf("%d\n",par);
        sum=sum+par;
        cont++;
    }
    printf("La suma es: %d",sum);
}
