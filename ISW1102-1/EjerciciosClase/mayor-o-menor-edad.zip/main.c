/******************************************************************************
Crear un programa que permita ingresar el nombre de una persona y su edad,
verificar si es mayor o menor de edad

Datos
Cadena de caracteres nombre
entero edad

Proceso
escribir "Ingrese el nombre"
leer nombre
Escribir "Ingrese la edad"
leer edad
Si (edad < 18) entonces
    escribir "nombre es mayor de edad"
sino 
    "nombre es menor de edad"

Salida
escribir "nombre es mayor de edad" o "nombre es menor de edad"
*******************************************************************************/
#include <stdio.h>

void main()
{
    int edad;
    char nombre[10];
    printf("Ingrese el nombre:");
    gets(nombre);
    printf("Ingrese la edad:");
    scanf ("%d",&edad);
    if (edad>=18){
        printf("%s es mayor de edad",nombre);}
    else{
        printf("%s es menor de edad",nombre);}
}
