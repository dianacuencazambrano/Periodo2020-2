/*****************************************************************************
Crear un programa que determine el factorial de un numero
5!=120
1*2*3*4*5

Pasos para usar funciones

1. Definir las librerias
2. Definicion de la funcion
3. LLamada a la funcion en funcion main()
4. Implementacion de la funion

Programa: Calcular la suma de n numeros
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int factorial(int);
void tablaMult(int,int);
int sumaNum(int);

void main()
{
    int num,limite,op;
    while(op!=3)
    {
    printf("1.Factorial\n2.Tabla de Multiplicar\n3.Suma de Números\n4.Salir\n");
    printf("Escoja una opcion:");
    scanf("%d",&op);
    
        switch(op)
        {
            case 1:
                printf("Ingrese el numero:");
                scanf("%d",&num);
                while(num<0 )
                {
                    printf("Ingrese un numero positivo:");
                    scanf("%d",&num);
    
                }
                printf("El factorial de %d es %d\n",num,factorial(num));
            break;
            case 2:
                printf("Ingrese la tabla a multiplicar:");
                scanf("%d",&num);
                printf("Ingrese el limite:");
                scanf("%d",&limite);
                tablaMult(num,limite);
            break;
            case 3:
            {
                printf("Ingrese la cantidad de numeros:");
                scanf("%d",&num);
                while(num<0)
                {
                    printf("Ingrese un numero positivo:");
                    scanf("%d",&num);
                }
                printf("La suma es: %d", sumaNum(num));
            }
            case 4:
                exit(0);
            break;
        }
    }
    
    
}

int factorial(int numero)
{
    int fact=1,cont=1;
    while(cont<=numero)
    {
        fact=fact*cont;
        cont++;
    }
    return fact;
}

void tablaMult(int numero,int lim)
{
    int mult=1,cont;
    for(cont=1;cont<=lim;cont++)
    {
        mult=numero*cont;
        printf("%dX%d=%d\n",numero,cont,mult);
    }
    
}
int sumaNum (int lim)
{
    int cont=1,num, sum=0;
    while(cont<=lim)
    {
        printf("Ingrese el numero %d:", cont);
        scanf("%d",&num);
        while(num<=0)
        {
            printf("Ingrese nuevamente: ");
            scanf("%d",&num);
        }
        sum=sum+num;
        cont++;
    }
    return sum;
    
}




