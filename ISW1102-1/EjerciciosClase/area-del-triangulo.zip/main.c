/*realizar un programa que calcule el área de un triángulo*/

#include<stdio.h>
void main()
{
    float base,altura,area=0;
    printf("Ingrese la base: ");
    scanf("%f",&base);
    printf("Ingrese la altura: ");
    scanf("%f",&altura);
    area=(base*altura)/2;
    printf("El área del triángulo es %.1f cm", area);
}
